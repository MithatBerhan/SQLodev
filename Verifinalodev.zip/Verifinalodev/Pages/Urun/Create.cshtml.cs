using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Verifinalodev.Pages.Urun
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
